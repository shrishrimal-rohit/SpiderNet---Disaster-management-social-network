OssnSmilies
===========

Convert ascii patterns to smileys.

Supports:

:(
:)
=D
;)
:p
8|
o.O
:O
:*
a:
:h:
3:|
u:
:v
g:
8)
c:

