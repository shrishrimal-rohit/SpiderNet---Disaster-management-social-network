OssnBlock
==========

Allow users to block other users.

Blocked user can't:

* Access Profile
* Send message
* View users wall posts