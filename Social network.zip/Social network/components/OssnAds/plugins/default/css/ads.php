.ossn-ad-item {
    border-bottom: 1px solid #eee;
    margin-bottom: 10px;
}