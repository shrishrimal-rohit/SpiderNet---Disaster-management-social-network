rm ./installation/INSTALLED
rm ./configurations/ossn.config.db.php
rm ./configurations/ossn.config.site.php
